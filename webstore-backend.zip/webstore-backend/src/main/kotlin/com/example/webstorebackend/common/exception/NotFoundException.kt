package com.example.webstorebackend.common.exception

class NotFoundException(message: String) : RuntimeException(message)