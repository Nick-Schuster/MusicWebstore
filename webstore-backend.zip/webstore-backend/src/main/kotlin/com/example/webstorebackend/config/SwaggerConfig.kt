package com.example.webstorebackend.config

class SwaggerConfig {
}